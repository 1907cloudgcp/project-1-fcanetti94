# RevAntarctica
  - Requirements are in the project under RevAntarctica.docx
  - Refer to [web-server-demo](https://github.com/1907cloudgcp/web-server-demo) for instructions about setting up a node server
